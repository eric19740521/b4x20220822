package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.b4xmainpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public anywheresoftware.b4a.objects.SocketWrapper _socket1 = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _label1 = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public String  _astream_error() throws Exception{
 //BA.debugLineNum = 91;BA.debugLine="Sub AStream_Error";
 //BA.debugLineNum = 92;BA.debugLine="Log(\"client AStream_Error==>\")";
__c.LogImpl("610027009","client AStream_Error==>",0);
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public void  _astream_newdata(byte[] _buffer) throws Exception{
ResumableSub_AStream_NewData rsub = new ResumableSub_AStream_NewData(this,_buffer);
rsub.resume(ba, null);
}
public static class ResumableSub_AStream_NewData extends BA.ResumableSub {
public ResumableSub_AStream_NewData(b4a.example.b4xmainpage parent,byte[] _buffer) {
this.parent = parent;
this._buffer = _buffer;
}
b4a.example.b4xmainpage parent;
byte[] _buffer;
String _lc_rec = "";

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 110;BA.debugLine="Log(\"client AStream_NewData==>\")";
parent.__c.LogImpl("610158081","client AStream_NewData==>",0);
 //BA.debugLineNum = 112;BA.debugLine="Try";
if (true) break;

case 1:
//try
this.state = 6;
this.catchState = 5;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 6;
this.catchState = 5;
 //BA.debugLineNum = 114;BA.debugLine="Dim lc_rec As String";
_lc_rec = "";
 //BA.debugLineNum = 115;BA.debugLine="lc_rec = BytesToString(Buffer, 0, Buffer.Length,";
_lc_rec = parent.__c.BytesToString(_buffer,(int) (0),_buffer.length,"UTF8");
 //BA.debugLineNum = 117;BA.debugLine="Log(\"===========================================";
parent.__c.LogImpl("610158088","================================================",0);
 //BA.debugLineNum = 118;BA.debugLine="Log(\"來自client訊息: \"&CRLF&lc_rec)";
parent.__c.LogImpl("610158089","來自client訊息: "+parent.__c.CRLF+_lc_rec,0);
 //BA.debugLineNum = 120;BA.debugLine="SendData";
parent._senddata();
 //BA.debugLineNum = 122;BA.debugLine="Sleep(300)";
parent.__c.Sleep(ba,this,(int) (300));
this.state = 7;
return;
case 7:
//C
this.state = 6;
;
 //BA.debugLineNum = 123;BA.debugLine="Log(\"結束連線~~~\")";
parent.__c.LogImpl("610158094","結束連線~~~",0);
 //BA.debugLineNum = 124;BA.debugLine="astream.Close";
parent._astream.Close();
 //BA.debugLineNum = 125;BA.debugLine="socket1.Close";
parent._socket1.Close();
 //BA.debugLineNum = 127;BA.debugLine="Log(\"===========================================";
parent.__c.LogImpl("610158098","================================================",0);
 if (true) break;

case 5:
//C
this.state = 6;
this.catchState = 0;
 //BA.debugLineNum = 132;BA.debugLine="Log(LastException)";
parent.__c.LogImpl("610158103",BA.ObjectToString(parent.__c.LastException(ba)),0);
 if (true) break;
if (true) break;

case 6:
//C
this.state = -1;
this.catchState = 0;
;
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 100;BA.debugLine="Sub AStream_Terminated";
 //BA.debugLineNum = 101;BA.debugLine="Log(\"client AStream_Terminated==>\")";
__c.LogImpl("610092545","client AStream_Terminated==>",0);
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 26;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 27;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public String  _button1_click() throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Private Sub Button1_Click";
 //BA.debugLineNum = 35;BA.debugLine="Try";
try { //BA.debugLineNum = 37;BA.debugLine="If server.IsInitialized = False Then";
if (_server.IsInitialized()==__c.False) { 
 //BA.debugLineNum = 39;BA.debugLine="server.Initialize(\"51042\", \"server\")		'server物件";
_server.Initialize(ba,(int)(Double.parseDouble("51042")),"server");
 //BA.debugLineNum = 41;BA.debugLine="Label1.Text = \"My IP: \" & server.GetMyIP &\" por";
_label1.setText(BA.ObjectToCharSequence("My IP: "+_server.GetMyIP()+" port:51042"));
 //BA.debugLineNum = 43;BA.debugLine="server.Listen							'server正在聆聽";
_server.Listen();
 //BA.debugLineNum = 44;BA.debugLine="Log(\"Server 服務器啟動...\")";
__c.LogImpl("6786444","Server 服務器啟動...",0);
 //BA.debugLineNum = 47;BA.debugLine="xui.MsgboxAsync(\"Server 服務器啟動...\", \"B4X\")";
_xui.MsgboxAsync(ba,BA.ObjectToCharSequence("Server 服務器啟動..."),BA.ObjectToCharSequence("B4X"));
 }else {
 //BA.debugLineNum = 49;BA.debugLine="Log(\"Server已啟動\")";
__c.LogImpl("6786449","Server已啟動",0);
 //BA.debugLineNum = 50;BA.debugLine="xui.MsgboxAsync(\"Server已啟動\", \"B4X\")";
_xui.MsgboxAsync(ba,BA.ObjectToCharSequence("Server已啟動"),BA.ObjectToCharSequence("B4X"));
 };
 } 
       catch (Exception e13) {
			ba.setLastException(e13); //BA.debugLineNum = 56;BA.debugLine="Log(LastException)";
__c.LogImpl("6786456",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Public server As ServerSocket		'jNetwork lib.服務器端";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Public socket1 As Socket			'jNetwork lib.客戶端 sock";
_socket1 = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private astream As AsyncStreams		'jRandomAccessFi";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 17;BA.debugLine="Private Label1 As B4XView";
_label1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 20;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _senddata() throws Exception{
String _lc_str = "";
String _msg = "";
 //BA.debugLineNum = 138;BA.debugLine="Sub SendData()";
 //BA.debugLineNum = 140;BA.debugLine="Dim lc_str,msg As String";
_lc_str = "";
_msg = "";
 //BA.debugLineNum = 143;BA.debugLine="msg=\"test hello,B4X\"";
_msg = "test hello,B4X";
 //BA.debugLineNum = 144;BA.debugLine="msg=\"<h1>test hello,B4X<h1>\"";
_msg = "<h1>test hello,B4X<h1>";
 //BA.debugLineNum = 145;BA.debugLine="msg=$\" <html> <head>  	<meta name=\"viewport\" cont";
_msg = ("\n"+"<html>\n"+"<head>\n"+" 	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"+"	<meta http-equiv=\"content-type\" content=\"text/html;charset=utf-8\">	\n"+"	<title>B4X Http Server</title>\n"+"	<script src=\"https://code.jquery.com/jquery-latest.min.js\" type=\"text/javascript\"></script>\n"+"	<style>\n"+"		html {\n"+"			height: 100%;\n"+"		}\n"+"		body {\n"+"			height: 100%;\n"+"			background-repeat: no-repeat;\n"+"			background-attachment: fixed;\n"+"			background: #f0f9ff; /* Old browsers */\n"+"			background: -moz-linear-gradient(top,  #f0f9ff 0%, #cbebff 47%, #a1dbff 100%); /* FF3.6+ */\n"+"			background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#f0f9ff), color-stop(47%,#cbebff), color-stop(100%,#a1dbff)); /* Chrome,Safari4+ */\n"+"			background: -webkit-linear-gradient(top,  #f0f9ff 0%,#cbebff 47%,#a1dbff 100%); /* Chrome10+,Safari5.1+ */\n"+"			background: -o-linear-gradient(top,  #f0f9ff 0%,#cbebff 47%,#a1dbff 100%); /* Opera 11.10+ */\n"+"			background: -ms-linear-gradient(top,  #f0f9ff 0%,#cbebff 47%,#a1dbff 100%); /* IE10+ */\n"+"			background: linear-gradient(to bottom,  #f0f9ff 0%,#cbebff 47%,#a1dbff 100%); /* W3C */\n"+"		}\n"+"		\n"+"		\n"+"	\n"+"	</style>\n"+"</head>\n"+"<body>\n"+"\n"+"	<div style=\"width: 500px;margin-left:auto; margin-right: auto;\">\n"+"	<h1>B4X Http Server</h1>\n"+"	<ul>\n"+"		<li><a href=\"https://www.b4x.com/\">B4X程式</a>\n"+"		<li><a href=\"http://b234.top\">NewPos</a>\n"+"	</ul>\n"+"	</div>\n"+" \n"+"	\n"+"	\n"+"	\n"+"	\n"+"</body>\n"+"</html>\n"+"	");
 //BA.debugLineNum = 196;BA.debugLine="lc_str = $\" HTTP/1.0 200 OK   Content-Type: text/";
_lc_str = ("\n"+"HTTP/1.0 200 OK  \n"+"Content-Type: text/html  \n"+"Contgent-Length: "+__c.SmartStringFormatter("",(Object)(_msg.length()))+"\n"+"  \n"+"  \n"+""+__c.SmartStringFormatter("",(Object)(_msg))+" ");
 //BA.debugLineNum = 206;BA.debugLine="astream.Write(lc_str.GetBytes(\"utf8\"))";
_astream.Write(_lc_str.getBytes("utf8"));
 //BA.debugLineNum = 210;BA.debugLine="End Sub";
return "";
}
public String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Sub server_NewConnection (Successful As Boolean, N";
 //BA.debugLineNum = 64;BA.debugLine="Log(\"New connection==>\")";
__c.LogImpl("69961473","New connection==>",0);
 //BA.debugLineNum = 66;BA.debugLine="DateTime.DateFormat = \"yyyy.MM.dd HH:mm:ss\"";
__c.DateTime.setDateFormat("yyyy.MM.dd HH:mm:ss");
 //BA.debugLineNum = 67;BA.debugLine="Log(\"目前時間: \"&DateTime.Date(DateTime.Now))";
__c.LogImpl("69961476","目前時間: "+__c.DateTime.Date(__c.DateTime.getNow()),0);
 //BA.debugLineNum = 70;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 71;BA.debugLine="Try";
try { //BA.debugLineNum = 72;BA.debugLine="socket1 = NewSocket";
_socket1 = _newsocket;
 //BA.debugLineNum = 74;BA.debugLine="astream.Initialize(NewSocket.InputStream, NewSo";
_astream.Initialize(ba,_newsocket.getInputStream(),_newsocket.getOutputStream(),"astream");
 } 
       catch (Exception e9) {
			ba.setLastException(e9); //BA.debugLineNum = 77;BA.debugLine="Log(\"client_err: \"&LastException)";
__c.LogImpl("69961486","client_err: "+BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 80;BA.debugLine="If astream.IsInitialized =True Then";
if (_astream.IsInitialized()==__c.True) { 
 //BA.debugLineNum = 81;BA.debugLine="Log(\"socket connect\")";
__c.LogImpl("69961490","socket connect",0);
 };
 };
 //BA.debugLineNum = 85;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
